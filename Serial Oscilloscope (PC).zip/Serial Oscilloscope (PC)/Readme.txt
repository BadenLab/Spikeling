This open source software is take from x-io technologies:

http://x-io.co.uk/serial-oscilloscope/

GitHub: https://github.com/xioTechnologies/Serial-Oscilloscope
